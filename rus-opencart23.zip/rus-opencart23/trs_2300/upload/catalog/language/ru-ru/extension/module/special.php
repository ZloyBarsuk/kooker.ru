<?php
// Heading
$_['heading_title'] = 'Акции';

// Text
$_['text_tax']      = 'Без НДС:';

