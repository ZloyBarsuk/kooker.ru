<?php
// Heading 
$_['heading_title']  = 'Latest Testimonials';
$_['text_readmore']  = 'Read more';
$_['text_empty']  = 'There is no testimonial';
?>