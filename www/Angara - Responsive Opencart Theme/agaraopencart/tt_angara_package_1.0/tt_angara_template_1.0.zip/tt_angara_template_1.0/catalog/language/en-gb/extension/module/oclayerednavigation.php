<?php
// Heading
$_['heading_title'] = 'Shop by';
$_['text_byprice'] = 'Price';