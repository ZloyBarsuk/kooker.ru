<?php
$_['text_readmore'] = 'Read more';