<?php
// Text
$_['text_items']     = 'Cart <span class="cart-number">%s<span class="cart-item">item</span></span>';
$_['text_empty']     = 'Your shopping cart is empty!';
$_['text_cart']      = 'View Cart';
$_['text_checkout']  = 'Checkout';
$_['text_recurring'] = 'Payment Profile';