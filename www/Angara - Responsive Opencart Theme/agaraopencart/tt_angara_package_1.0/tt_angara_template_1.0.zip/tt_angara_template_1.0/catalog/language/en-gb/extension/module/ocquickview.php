<?php
	// Text
	$_['text_quickview']  = 'Quick View'; 
	?>