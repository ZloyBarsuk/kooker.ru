<?php
// Heading
$_['heading_title'] = 'Random Product Slider';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_sale']      = 'Sale';
$_['text_new']      = 'New';
$_['text_empty']    = 'There is no Random Products!';