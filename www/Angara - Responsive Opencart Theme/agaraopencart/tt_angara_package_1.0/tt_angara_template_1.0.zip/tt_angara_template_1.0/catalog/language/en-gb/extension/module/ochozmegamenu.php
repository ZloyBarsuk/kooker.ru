<?php
// Heading 
$_['heading_title'] = 'Hozmegamenu';

// Text
$_['text_reviews']  = 'Based on %s reviews.';