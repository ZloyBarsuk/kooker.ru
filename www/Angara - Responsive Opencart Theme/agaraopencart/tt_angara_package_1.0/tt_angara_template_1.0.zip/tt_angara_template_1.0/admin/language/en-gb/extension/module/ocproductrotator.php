<?php
// Heading
$_['heading_title']    = '<b><i>OC Product Rotator Image</i></b>';
$_['page_title']       = 'OC Product Rotator Image';

// Text
$_['text_extension']      = 'Extensions';
$_['text_success']     = 'Success: You have modified Product Rotator Image module!';
$_['text_edit']        = 'Edit Product Rotator Image Module';

// Entry
$_['entry_name']       = 'Module Name';
$_['entry_status']     = 'Status';
$_['entry_is_rotator'] = 'Is Rotator Image';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Product Rotator Image module!';