<?php
// Heading
$_['heading_title']       = '<b><i>OC Template Installation</i></b>';
$_['page_title']       = 'OC Template Installation';

// Text
$_['text_extension']         = 'Extensions';
$_['text_sample_data']         = 'Sample Data have setup';
$_['text_success']     = 'Success: You have installed template!';