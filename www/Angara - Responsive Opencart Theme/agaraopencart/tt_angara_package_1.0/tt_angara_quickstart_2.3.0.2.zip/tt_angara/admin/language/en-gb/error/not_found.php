<?php
// Heading
$_['heading_title']  = 'Page Not Found!';

// Text
$_['text_not_found'] = 'The page you are looking for could not be found! Please contact your administrator if the problem persists.';